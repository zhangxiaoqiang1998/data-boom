# 流量去质器,机场主转辗反侧无法理解的东西

建议配合cloudflare pages食用，index内数据流改走本地目录下的data-waster-dummy    xhr[id] = $.get "https://"


汉化主页，多线程32




